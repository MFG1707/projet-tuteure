<?php

// Vérifier si le formulaire a été soumis
if ($_SERVER["REQUEST_METHOD"] == "POST") {

  // Récupérer les données du formulaire
  $email = $_POST["email"];
  $passport_number = $_POST["passport_number"];
  $ticket_type_id = $_POST["ticket_type_id"];
  $flight_number = $_POST["flight_number"];

  // Valider les données
  $errors = array();

  if (empty($email)) {
    $errors[] = "L'adresse email est requise";
  } else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors[] = "L'adresse email n'est pas valide";
  }

  if (empty($passport_number)) {
    $errors[] = "Le numéro de passeport est requis";
  }

  if (empty($ticket_type_id)) {
    $errors[] = "Le type de billet est requis";
  }

  if (empty($flight_number)) {
    $errors[] = "Le numéro de vol est requis";
  }

  // S'il y a des erreurs, les afficher et arrêter le traitement
  if (count($errors) > 0) {
    echo "<h2>Il y a des erreurs dans le formulaire :</h2>";
    echo "<ul>";
    foreach ($errors as $error) {
      echo "<li>$error</li>";
    }
    echo "</ul>";
    exit;
  }

  // Connexion à la base de données
  $servername = "localhost";
  $username = "root";
  $password = "root";
  $dbname = "FLIGHT";

  $conn = mysqli_connect($servername, $username, $password, $dbname);

  // Vérifier la connexion
  if (!$conn) {
    die("La connexion a échoué : " . mysqli_connect_error());
  }

  // Préparer la requête SQL
  $sql = "INSERT INTO bookings (reservation_date, email, flight_number, ticket_type_id, passport_number)
          VALUES (NOW(), '$email', '$flight_number', '$ticket_type_id', '$passport_number')";

  // Exécuter la requête SQL
  if (mysqli_query($conn, $sql)) {
    echo "<h2>Votre réservation a été enregistrée avec succès !</h2>";
  } else {
    echo "Erreur : " . mysqli_error($conn);
  }

  // Fermer la connexion
  mysqli_close($conn);

} else {
  // Si le formulaire n'a pas été soumis, rediriger vers la page de recherche de vols
  header("Location: search_flights.php");
  exit;
}
