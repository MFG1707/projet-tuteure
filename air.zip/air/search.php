<?php
	// Connexion à la base de données
	$conn = mysqli_connect("localhost", "root", "root", "FLIGHT");

	// Vérification de la connexion
	if (!$conn) {
		die("Erreur de connexion à la base de données: " . mysqli_connect_error());
	}

	// Récupération des données du formulaire de recherche
	$depart = $_GET['depart'];
	$arrivee = $_GET['arrivee'];
	$date_depart = $_GET['date_depart'];
	$date_arrivee = $_GET['date_arrivee'];
	$aller_retour = $_GET['aller_retour'];

	// Requête SQL pour récupérer les vols correspondants aux critères de recherche
	$sql = "SELECT * FROM flights WHERE depart='$depart' AND arrivee='$arrivee' AND date_depart='$date_depart'";

	if ($aller_retour == "oui") {
		$sql .= " AND date_arrivee='$date_arrivee'";
	}

	$resultat = mysqli_query($conn, $sql);

	// Affichage des résultats de la recherche
	if (mysqli_num_rows($resultat) > 0) {
		echo "<table border='1'>";
		echo "<tr><th>ID</th><th>Départ</th><th>Arrivée</th><th>Date de départ</th><th>Date d'arrivée</th><th>Prix</th></tr>";

		while ($ligne = mysqli_fetch_assoc($resultat)) {
			echo "<tr>";
			echo "<td>" . $ligne['id'] . "</td>";
			echo "<td>" . $ligne['depart'] . "</td>";
			echo "<td>" . $ligne['arrivee'] . "</td>";
			echo "<td>" . $ligne['date_depart'] . "</td>";
			echo "<td>" . $ligne['date_arrivee'] . "</td>";
			echo "<td>" . $ligne['prix'] . "</td>";
			echo "</tr>";
		}

		echo "</table>";
	} else {
		echo "Aucun résultat ne correspond à votre recherche.";
	}

	// Fermeture de la connexion à la base de données
	mysqli_close($conn);
	?>