<?php
                          session_start();

                          $host = "localhost"; // Adresse de la base de données
                          $username = "root"; // Nom d'utilisateur de la base de données
                          $password = "root"; // Mot de passe de la base de données
                          $dbname = "FLIGHT"; // Nom de la base de données

                          // Connexion à la base de données MySQL
                          $conn = mysqli_connect($host, $username, $password, $dbname);

                          if (!$conn) {
                              die("La connexion à la base de données a échoué: " . mysqli_connect_error());
                          }

                          $email = $_POST['email'];
                          $password = $_POST['password'];

                          // Vérification des identifiants
                          $sql = "SELECT * FROM users WHERE email = '$email' AND password = '$password'";
                          $result = mysqli_query($conn, $sql);

                          if (mysqli_num_rows($result) == 1) {
                              // L'utilisateur est connecté avec succès
                              $row = mysqli_fetch_assoc($result);

                              // Stockage de l'utilisateur en session
                              $_SESSION['user'] = $row;

                              if ($row['type'] == 'admin') {
                                session_write_close();
                                header("Location: admin.php");
                            } else {
                                session_write_close();
                                header("Location: index.php");
                            }
                            

                              // Redirection en fonction du type d'utilisateur
                              if ($row['type'] == 'admin') {
                                  header("Location: admin.php");
                              } else {
                                  header("Location: index.php");
                              }
                          } else {
                              // Les identifiants sont incorrects
                              header("Location: login.php?error=1");
                          }

                          mysqli_close($conn);
                        ?>